 #include <iostream>
 #include <string>
 #include <assert.h>
 #include <cmath>

 using namespace std;
 
 // GLAD
 #include <glad/glad.h>
 
 // GLFW
 #include <GLFW/glfw3.h>

 // VECTOR
 #include <vector>

 const float Pi = 3.14159;
 
 // Protótipo da função de callback de teclado
 void key_callback(GLFWwindow *window, int key, int scancode, int action, int mode);
 
 // Protótipos das funções
 int setupShader();
 int setupGeometry();
 int createCircle(int nPoints, float radius = 0.5);
 
 // Dimensões da janela (pode ser alterado em tempo de execução)
 const GLuint WIDTH = 800, HEIGHT = 800;
 
 // Código fonte do Vertex Shader (em GLSL): ainda hardcoded
 const GLchar *vertexShaderSource = R"(
  #version 400
  layout (location = 0) in vec3 position;
  void main()
  {
      gl_Position = vec4(position.x, position.y, position.z, 1.0);
  }
  )";
 
 // Código fonte do Fragment Shader (em GLSL): ainda hardcoded
 const GLchar *fragmentShaderSource = R"(
  #version 400
  uniform vec4 inputColor;
  out vec4 color;
  void main()
  {
      color = inputColor;
  }
  )";
 
 // Função MAIN
 int main()
 {
     // Inicialização da GLFW
     glfwInit();
 
     // Muita atenção aqui: alguns ambientes não aceitam essas configurações
     // Você deve adaptar para a versão do OpenGL suportada por sua placa
     // Sugestão: comente essas linhas de código para desobrir a versão e
     // depois atualize (por exemplo: 4.5 com 4 e 5)
     // glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
     // glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 6);
     // glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
     // glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
 
     // Ativa a suavização de serrilhado (MSAA) com 8 amostras por pixel
     glfwWindowHint(GLFW_SAMPLES, 8);
 
     // Essencial para computadores da Apple
     // #ifdef __APPLE__
     //	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
     // #endif
 
     // Criação da janela GLFW
     GLFWwindow *window = glfwCreateWindow(WIDTH, HEIGHT, "Octagono -- Ender", nullptr, nullptr);
     if (!window)
     {
         std::cerr << "Falha ao criar a janela GLFW" << std::endl;
         glfwTerminate();
         return -1;
     }
     glfwMakeContextCurrent(window);
 
     // Fazendo o registro da função de callback para a janela GLFW
     glfwSetKeyCallback(window, key_callback);
 
     // GLAD: carrega todos os ponteiros d funções da OpenGL
     if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
     {
         std::cerr << "Falha ao inicializar GLAD" << std::endl;
         return -1;
     }
 
     // Obtendo as informações de versão
     const GLubyte *renderer = glGetString(GL_RENDERER); /* get renderer string */
     const GLubyte *version = glGetString(GL_VERSION);	/* version as a string */
     cout << "Renderer: " << renderer << endl;
     cout << "OpenGL version supported " << version << endl;
 
     // Definindo as dimensões da viewport com as mesmas dimensões da janela da aplicação
     int width, height;
     glfwGetFramebufferSize(window, &width, &height);
     glViewport(0, 0, width, height);
 
     // Compilando e buildando o programa de shader
     GLuint shaderID = setupShader();
 
     // Gerando um buffer simples, com a geometria de um triângulo
     int nPoints = 8;
     GLuint VAO = createCircle(nPoints);
     int nVertices = nPoints + 2;
 
     // Enviando a cor desejada (vec4) para o fragment shader
     // Utilizamos a variáveis do tipo uniform em GLSL para armazenar esse tipo de info
     // que não está nos buffers
     GLint colorLoc = glGetUniformLocation(shaderID, "inputColor");
 
     glUseProgram(shaderID); // Reseta o estado do shader para evitar problemas futuros
 
     double prev_s = glfwGetTime();	// Define o "tempo anterior" inicial.
     double title_countdown_s = 0.1; // Intervalo para atualizar o título da janela com o FPS.
 
     float colorValue = 0.0;
     // Loop da aplicação - "game loop"
     while (!glfwWindowShouldClose(window))
     {
         // Checa se houveram eventos de input (key pressed, mouse moved etc.) e chama as funções de callback correspondentes
         glfwPollEvents();
 
         // Limpa o buffer de cor
         glClearColor(0.0f, 0.0f, 0.0f, 1.0f); // cor de fundo
         glClear(GL_COLOR_BUFFER_BIT);
 
         glLineWidth(10);
         glPointSize(20);
 
         glBindVertexArray(VAO); // Conectando ao buffer de geometria
 
         
         // Chamada de desenho - drawcall
         // item a) exercicio 7
         glUniform4f(colorLoc, 0.9f, 0.9f, 0.9f, 1.0f);
         glDrawArrays(GL_TRIANGLE_FAN, 0, nVertices);

 
         // glBindVertexArray(0); // Desnecessário aqui, pois não há múltiplos VAOs
 
         // Troca os buffers da tela
         glfwSwapBuffers(window);
     }
     // Pede pra OpenGL desalocar os buffers
     glDeleteVertexArrays(1, &VAO);
     // Finaliza a execução da GLFW, limpando os recursos alocados por ela
     glfwTerminate();
     return 0;
 }
 
 // Função de callback de teclado - só pode ter uma instância (deve ser estática se
 // estiver dentro de uma classe) - É chamada sempre que uma tecla for pressionada
 // ou solta via GLFW
 void key_callback(GLFWwindow *window, int key, int scancode, int action, int mode)
 {
     if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
         glfwSetWindowShouldClose(window, GL_TRUE);
 }
 
 // Esta função está bastante hardcoded - objetivo é compilar e "buildar" um programa de
 //  shader simples e único neste exemplo de código
 //  O código fonte do vertex e fragment shader está nos arrays vertexShaderSource e
 //  fragmentShader source no iniçio deste arquivo
 //  A função retorna o identificador do programa de shader
 int setupShader()
 {
     // Vertex shader
     GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);
     glShaderSource(vertexShader, 1, &vertexShaderSource, NULL);
     glCompileShader(vertexShader);
     // Checando erros de compilação (exibição via log no terminal)
     GLint success;
     GLchar infoLog[512];
     glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &success);
     if (!success)
     {
         glGetShaderInfoLog(vertexShader, 512, NULL, infoLog);
         std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n"
                   << infoLog << std::endl;
     }
     // Fragment shader
     GLuint fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
     glShaderSource(fragmentShader, 1, &fragmentShaderSource, NULL);
     glCompileShader(fragmentShader);
     // Checando erros de compilação (exibição via log no terminal)
     glGetShaderiv(fragmentShader, GL_COMPILE_STATUS, &success);
     if (!success)
     {
         glGetShaderInfoLog(fragmentShader, 512, NULL, infoLog);
         std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n"
                   << infoLog << std::endl;
     }
     // Linkando os shaders e criando o identificador do programa de shader
     GLuint shaderProgram = glCreateProgram();
     glAttachShader(shaderProgram, vertexShader);
     glAttachShader(shaderProgram, fragmentShader);
     glLinkProgram(shaderProgram);
     // Checando por erros de linkagem
     glGetProgramiv(shaderProgram, GL_LINK_STATUS, &success);
     if (!success)
     {
         glGetProgramInfoLog(shaderProgram, 512, NULL, infoLog);
         std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n"
                   << infoLog << std::endl;
     }
     glDeleteShader(vertexShader);
     glDeleteShader(fragmentShader);
 
     return shaderProgram;
 }
 
 // Esta função está bastante harcoded - objetivo é criar os buffers que armazenam a
 // geometria de um triângulo
 // Apenas atributo coordenada nos vértices
 // 1 VBO com as coordenadas, VAO com apenas 1 ponteiro para atributo
 // A função retorna o identificador do VAO

 int createCircle(int nPoints, float radius) 
 {
    vector <GLfloat> vertices;

    float angle = 0.0;
    float slice = 2 * Pi / (float)nPoints;

    vertices.push_back(0.0);
    vertices.push_back(0.0);
    vertices.push_back(0.0);

    for (int i = 0; i <= nPoints; i++) {
        float x = radius * cos(angle);
        float y = radius * sin(angle);
        float z = 0.0;

        vertices.push_back(x);
        vertices.push_back(y);
        vertices.push_back(z);

        angle += slice;
    }

    GLuint VBO, VAO;
    glGenBuffers(1, &VBO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(GLfloat), vertices.data(), GL_STATIC_DRAW);
    glGenVertexArrays(1, &VAO);
    glBindVertexArray(VAO);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid *)0);
    glEnableVertexAttribArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);

    return VAO;
 }